__version__ = "0.1.0"
__author__ = 'Pavel Sutormin'
__credits__ = None