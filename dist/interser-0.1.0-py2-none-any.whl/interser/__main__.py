from PIL import Image
import numpy as np
import random
w, h = 512, 512
data = np.zeros((h, w, 3), dtype=np.uint8)
data[0:256, 0:256] = [random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)]
mnm = Image.fromarray(np.uint8(data))
mnm.show()